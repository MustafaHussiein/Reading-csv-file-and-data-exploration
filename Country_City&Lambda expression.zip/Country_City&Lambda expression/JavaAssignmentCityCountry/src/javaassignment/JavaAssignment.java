/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaassignment;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author dell
 */
public class JavaAssignment {

    /**
     * @param args the command line arguments
     */
    
    public static List<String> arr;
    public static List<String> arr1;
    public static void main(String[] args) {
        // Reading from city.csv and creating list of cities
        File file = new File("C:\\Users\\dell\\Downloads\\city.csv");
        List<Cities> cities = new ArrayList<Cities>();
        Cities c1 = new Cities();
        String code, name, continent;
        String Surface_Area;
        String population;
        try {
            BufferedReader csvReader = new BufferedReader(new FileReader(file));
            String row;
            while ((row = csvReader.readLine()) != null) {
                         String[] data = row.split(",");
                         code = data[1];
                         name = data[0];
                         continent = data[2];
                         Surface_Area = data[3];
                         population =  data[4];
                         c1 = new Cities(code,name,continent,Surface_Area,population);
                         cities.add(c1);
                         
    // do something with the data
}
csvReader.close();
        }catch (IOException ex) {
            Logger.getLogger(JavaAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        // Reading from country.csv and creating list of countries
        File file1 = new File("C:\\Users\\dell\\Downloads\\country.csv");
        List<Countries> countries = new ArrayList<Countries>();
        Countries cu1 = new Countries();
        String nameCountry;
        String codeCountry;
        String[] citiesCountry;
        HashMap<String , String[]> map = new HashMap<String , String[]>();
        try {
            BufferedReader csvReader1 = new BufferedReader(new FileReader(file1));
            String row;
            while ((row = csvReader1.readLine()) != null) {
                         String[] data = row.split(",");
                         codeCountry = data[1];
                         nameCountry = data[0];
                         String cC = data[2];
                         citiesCountry = cC.split(";");
                         cu1 = new Countries(nameCountry,codeCountry,citiesCountry);
                         countries.add(cu1);
                         cu1.setCity_list(citiesCountry);
                         cu1.setCountry_code(codeCountry);
                         map.put(cu1.getCountry_code(), cu1.getCity_list());
    // do something with the data
}
            Sort("11011",countries, cities);
            //System.out.println(countries);
csvReader1.close();
        } catch (IOException ex) {
            Logger.getLogger(JavaAssignment.class.getName()).log(Level.SEVERE, null, ex);
        }
        
       
    }
    public static void Sort(String code_country, List<Countries> countries, List<Cities> cities){
        arr = new ArrayList<>();
        arr1 = new ArrayList<>();
          for(int i=0; i< countries.size();i++){
            if(countries.get(i).getCountry_code().contains(code_country)){
                arr = convertArrayToList(countries.get(i).getCity_list());
            }
        }
          for(int j=0; j< arr.size(); j++){
              for(int p =0; p<cities.size(); p++){
                  if(cities.get(p).name.contains(arr.get(j)))
                      arr1.add(cities.get(p).getPopulation());
                  Collections.sort(arr1);
              }
            }
          for(int y=0; y<arr1.size(); y++){
                for(int k =0; k<cities.size(); k++){
                    if(cities.get(k).getPopulation() == arr1.get(y))
                             System.out.println(cities.get(k).getName());
                         }
    }
    }
    public static <T> List<T> convertArrayToList(T array[])
    {
  
        // Create an empty List
        List<T> list = new ArrayList<>();
  
        // Iterate through the array
        for (T t : array) {
            // Add each element into the list
            list.add(t);
        }
  
        // Return the converted List
        return list;
    }
          
    
}
