/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaassignment;

/**
 *
 * @author dell
 */
public class Cities {
    String code, name, continent;
    String Surface_Area;
    String population;
    public Cities(String c, String n, String co, String s, String p ){
    
        this.code = c;
        this.name = n;
        this.continent = co;
        this.Surface_Area = s;
        this.population = p;
    }

    Cities() {
        //To change body of generated methods, choose Tools | Templates.
    }
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }
     public String getPopulation() {
        return population;
    }

    /**
     * @param population the population to set
     */
    public void setPopulation(String population) {
        this.population = population;
    }

}
