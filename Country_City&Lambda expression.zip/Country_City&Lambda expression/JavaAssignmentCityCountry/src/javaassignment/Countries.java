/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaassignment;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author dell
 */
public class Countries {
    private String name;
    private String code;
    private String[] cities;
    public Countries(String country_name,String country_code, String[] city_list) {
        this.name=country_name;
        this.code = country_code;
        this.cities = city_list;
        
    }

    Countries() {
        //To change body of generated methods, choose Tools | Templates.
    }
    public String[] getCity_list() {
        return this.cities;
    }

    /**
     * @param city_list the city_list to set
     */
    public void setCity_list(String[] city_list) {
        this.cities = city_list;
    }
    public String getCountry_code() {
        return this.code;
    }

    /**
     * @param country_code the country_code to set
     */
    public void setCountry_code(String country_code) {
        this.code = country_code;
    }
public String getCountry_name() {
        return name;
    }

    /**
     * @param country_name the country_name to set
     */
    public void setCountry_name(String country_name) {
        this.name = country_name;
    }
     
}
